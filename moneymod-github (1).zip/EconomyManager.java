package com.example.moneymod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Серверное хранилище денег и разблокировок. Всё считается только на сервере. */
public final class EconomyManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Map<String, PlayerData> data = new HashMap<>();
    private static Path file;

    public static final class PlayerData {
        public long balance = 0;
        public Set<String> unlocked = new HashSet<>();
    }

    private EconomyManager() {}

    public static void load(MinecraftServer server) {
        file = server.getWorldPath(LevelResource.ROOT).resolve("moneymod.json");
        data = new HashMap<>();
        if (Files.exists(file)) {
            try (Reader r = Files.newBufferedReader(file)) {
                Map<String, PlayerData> loaded = GSON.fromJson(r, new TypeToken<Map<String, PlayerData>>() {}.getType());
                if (loaded != null) data = loaded;
            } catch (IOException | RuntimeException e) {
                System.err.println("[moneymod] Не удалось загрузить данные: " + e);
            }
        }
    }

    public static void save() {
        if (file == null) return;
        try (Writer w = Files.newBufferedWriter(file)) {
            GSON.toJson(data, w);
        } catch (IOException e) {
            System.err.println("[moneymod] Не удалось сохранить данные: " + e);
        }
    }

    public static PlayerData get(UUID id) {
        return data.computeIfAbsent(id.toString(), k -> new PlayerData());
    }

    public static long balance(UUID id) {
        return get(id).balance;
    }

    public static void add(UUID id, long amount) {
        get(id).balance += amount;
    }

    public static boolean has(UUID id, Unlock u) {
        return get(id).unlocked.contains(u.id);
    }

    /** Покупка разблокировки. Возвращает true, если куплено. */
    public static boolean buy(UUID id, Unlock u) {
        PlayerData d = get(id);
        if (d.unlocked.contains(u.id) || d.balance < u.price) return false;
        d.balance -= u.price;
        d.unlocked.add(u.id);
        return true;
    }
}
