package com.example.moneymod;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class GameEvents {
    private static final ResourceLocation NO_JUMP =
        ResourceLocation.fromNamespaceAndPath(MoneyMod.MODID, "no_jump");
    private static final int MAX_TREE_BLOCKS = 128;

    private GameEvents() {}

    /** true = запретить действие (нет разблокировки). */
    private static boolean denied(Player player, Unlock u) {
        if (!(player instanceof ServerPlayer sp)) return false;
        if (EconomyManager.has(sp.getUUID(), u)) return false;
        sp.displayClientMessage(
            Component.literal("Заблокировано: «" + u.title + "». Купи: /buy " + u.id), true);
        return true;
    }

    public static boolean onBreak(BlockEvent.BreakEvent e) {
        Player p = e.getPlayer();
        if (denied(p, Unlock.BREAK)) return true;

        if (p instanceof ServerPlayer sp && e.getLevel() instanceof ServerLevel level) {
            ItemStack held = sp.getMainHandItem();
            BlockPos origin = e.getPos();
            BlockState state = e.getState();
            if (Machine.SAW.matches(held) && state.is(BlockTags.LOGS)) {
                fellTree(level, sp, origin, held);
            } else if (Machine.DRILL.matches(held)) {
                drill(level, sp, origin, held);
            }
        }
        return false;
    }

    /** Пила: валит всё дерево целиком (соседние брёвна). */
    private static void fellTree(ServerLevel level, ServerPlayer sp, BlockPos origin, ItemStack tool) {
        Set<BlockPos> seen = new HashSet<>();
        List<BlockPos> found = new ArrayList<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        seen.add(origin);
        queue.add(origin);
        while (!queue.isEmpty() && found.size() < MAX_TREE_BLOCKS) {
            BlockPos cur = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        BlockPos n = cur.offset(dx, dy, dz);
                        if (!seen.add(n)) continue;
                        if (level.getBlockState(n).is(BlockTags.LOGS)) {
                            found.add(n);
                            queue.add(n);
                        }
                    }
                }
            }
        }
        for (BlockPos pos : found) level.destroyBlock(pos, true, sp);
        tool.hurtAndBreak(1, sp, EquipmentSlot.MAINHAND);
    }

    /** Бур: ломает блоки 3x3x3 вокруг (только то, что берёт кирка, без бедрока). */
    private static void drill(ServerLevel level, ServerPlayer sp, BlockPos origin, ItemStack tool) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (dx == 0 && dy == 0 && dz == 0) continue;
                    BlockPos pos = origin.offset(dx, dy, dz);
                    BlockState st = level.getBlockState(pos);
                    float hardness = st.getDestroySpeed(level, pos);
                    if (st.is(BlockTags.MINEABLE_WITH_PICKAXE) && hardness >= 0 && hardness <= 5) {
                        level.destroyBlock(pos, true, sp);
                    }
                }
            }
        }
        tool.hurtAndBreak(1, sp, EquipmentSlot.MAINHAND);
    }

    public static boolean onPlace(BlockEvent.EntityPlaceEvent e) {
        Entity ent = e.getEntity();
        return ent instanceof Player p && denied(p, Unlock.PLACE);
    }

    public static boolean onAttack(AttackEntityEvent e) {
        return denied(e.getEntity(), Unlock.ATTACK);
    }

    /**
     * ПКМ по золотому блоку пустой рукой = кликер (+1 монета).
     * ПКМ по изумрудному блоку с ресурсом в руке = скупщик продаёт то, что в руке.
     */
    public static boolean onRightClickBlock(PlayerInteractEvent.RightClickBlock e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return false;
        if (e.getHand() != InteractionHand.MAIN_HAND) return false;
        BlockState state = e.getLevel().getBlockState(e.getPos());

        if (state.is(Blocks.GOLD_BLOCK) && sp.getMainHandItem().isEmpty()) {
            EconomyManager.add(sp.getUUID(), 1);
            sp.displayClientMessage(
                Component.literal("+1 монета (баланс: " + EconomyManager.balance(sp.getUUID()) + ")"), true);
            return false;
        }

        if (state.is(Blocks.EMERALD_BLOCK) && !sp.getMainHandItem().isEmpty()) {
            long got = Prices.sellHand(sp);
            sp.displayClientMessage(Component.literal(
                got > 0 ? "Скупщик заплатил " + got + " монет" : "Скупщик это не берёт"), true);
            return true; // не ставить блок рядом
        }
        return false;
    }

    public static void onPlayerTick(TickEvent.PlayerTickEvent.Post e) {
        if (e.player() instanceof ServerPlayer sp && sp.tickCount % 20 == 0) {
            refreshJump(sp);
        }
    }

    /** Прыжок блокируем обнулением силы прыжка, пока не куплена разблокировка. */
    public static void refreshJump(ServerPlayer sp) {
        AttributeInstance attr = sp.getAttribute(Attributes.JUMP_STRENGTH);
        if (attr == null) return;
        boolean locked = !EconomyManager.has(sp.getUUID(), Unlock.JUMP);
        boolean has = attr.hasModifier(NO_JUMP);
        if (locked && !has) {
            attr.addTransientModifier(new AttributeModifier(
                NO_JUMP, -1.0, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        } else if (!locked && has) {
            attr.removeModifier(NO_JUMP);
        }
    }
}
