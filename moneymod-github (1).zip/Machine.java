package com.example.moneymod;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;

/** Техника: обычный инструмент с меткой. Способность включается в GameEvents. */
public enum Machine {
    SAW("saw", "Пила для дерева", 150, Items.IRON_AXE),
    DRILL("drill", "Бур для камня", 300, Items.IRON_PICKAXE);

    public final String id;
    public final String title;
    public final long price;
    private final Item base;

    Machine(String id, String title, long price, Item base) {
        this.id = id;
        this.title = title;
        this.price = price;
        this.base = base;
    }

    public static Machine byId(String id) {
        for (Machine m : values()) {
            if (m.id.equalsIgnoreCase(id)) return m;
        }
        return null;
    }

    public ItemStack create() {
        ItemStack s = new ItemStack(base);
        CompoundTag tag = new CompoundTag();
        tag.putBoolean("moneymod_" + id, true);
        s.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
        s.set(DataComponents.CUSTOM_NAME, Component.literal(title));
        return s;
    }

    public boolean matches(ItemStack s) {
        if (s.isEmpty()) return false;
        CustomData d = s.get(DataComponents.CUSTOM_DATA);
        return d != null && d.contains("moneymod_" + id);
    }
}
