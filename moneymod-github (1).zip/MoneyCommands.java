package com.example.moneymod;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public final class MoneyCommands {
    private MoneyCommands() {}

    private static void ok(CommandSourceStack src, String text) {
        src.sendSuccess(() -> Component.literal(text), false);
    }

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("balance").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            ok(ctx.getSource(), "Баланс: " + EconomyManager.balance(p.getUUID()) + " монет");
            return 1;
        }));

        d.register(Commands.literal("shop").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            StringBuilder sb = new StringBuilder("Магазин (/buy <id>):\nУмения:");
            for (Unlock u : Unlock.values()) {
                String mark = EconomyManager.has(p.getUUID(), u) ? " [куплено]" : "";
                sb.append("\n- ").append(u.id).append(": ").append(u.title)
                  .append(" — ").append(u.price).append(mark);
            }
            sb.append("\nТехника:");
            for (Machine m : Machine.values()) {
                sb.append("\n- ").append(m.id).append(": ").append(m.title)
                  .append(" — ").append(m.price);
            }
            ok(ctx.getSource(), sb.toString());
            return 1;
        }));

        d.register(Commands.literal("buy")
            .then(Commands.argument("id", StringArgumentType.word()).executes(ctx -> {
                CommandSourceStack src = ctx.getSource();
                ServerPlayer p = src.getPlayerOrException();
                String id = StringArgumentType.getString(ctx, "id");

                Unlock u = Unlock.byId(id);
                if (u != null) {
                    if (EconomyManager.has(p.getUUID(), u)) {
                        src.sendFailure(Component.literal("Уже куплено"));
                        return 0;
                    }
                    if (!EconomyManager.buy(p.getUUID(), u)) {
                        src.sendFailure(Component.literal("Не хватает денег: нужно " + u.price));
                        return 0;
                    }
                    GameEvents.refreshJump(p);
                    ok(src, "Куплено: " + u.title);
                    return 1;
                }

                Machine m = Machine.byId(id);
                if (m != null) {
                    if (EconomyManager.balance(p.getUUID()) < m.price) {
                        src.sendFailure(Component.literal("Не хватает денег: нужно " + m.price));
                        return 0;
                    }
                    EconomyManager.add(p.getUUID(), -m.price);
                    ItemStack stack = m.create();
                    if (!p.getInventory().add(stack)) p.drop(stack, false);
                    ok(src, "Куплено: " + m.title);
                    return 1;
                }

                src.sendFailure(Component.literal("Нет такого товара. Смотри /shop"));
                return 0;
            })));

        d.register(Commands.literal("sell").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            long got = Prices.sellHand(p);
            if (got <= 0) {
                ctx.getSource().sendFailure(Component.literal("Это не покупают (держи ресурс в руке)"));
                return 0;
            }
            ok(ctx.getSource(), "Продано за " + got + " монет");
            return 1;
        }));

        d.register(Commands.literal("sellall").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            long got = Prices.sellAll(p);
            if (got <= 0) {
                ctx.getSource().sendFailure(Component.literal("Нечего продавать"));
                return 0;
            }
            ok(ctx.getSource(), "Продано всё за " + got + " монет");
            return 1;
        }));
    }
}
