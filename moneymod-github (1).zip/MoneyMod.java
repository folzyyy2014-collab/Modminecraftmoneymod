package com.example.moneymod;

import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.fml.common.Mod;

@Mod(MoneyMod.MODID)
public class MoneyMod {
    public static final String MODID = "moneymod";
    private static int saveTimer = 0;

    public MoneyMod() {
        ServerStartedEvent.BUS.addListener(e -> EconomyManager.load(e.getServer()));
        ServerStoppingEvent.BUS.addListener(e -> EconomyManager.save());
        RegisterCommandsEvent.BUS.addListener(e -> MoneyCommands.register(e.getDispatcher()));

        BlockEvent.BreakEvent.BUS.addListener(GameEvents::onBreak);
        BlockEvent.EntityPlaceEvent.BUS.addListener(GameEvents::onPlace);
        AttackEntityEvent.BUS.addListener(GameEvents::onAttack);
        PlayerInteractEvent.RightClickBlock.BUS.addListener(GameEvents::onRightClickBlock);
        TickEvent.PlayerTickEvent.Post.BUS.addListener(GameEvents::onPlayerTick);

        // автосохранение раз в 5 минут
        TickEvent.ServerTickEvent.Post.BUS.addListener(e -> {
            if (++saveTimer >= 6000) {
                saveTimer = 0;
                EconomyManager.save();
            }
        });
    }
}
