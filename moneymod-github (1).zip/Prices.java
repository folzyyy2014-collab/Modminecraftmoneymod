package com.example.moneymod;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.HashMap;
import java.util.Map;

/** Таблица цен скупщика. Меняй цифры как хочешь. */
public final class Prices {
    private static final Map<Item, Integer> P = new HashMap<>();

    static {
        P.put(Items.COBBLESTONE, 1);
        P.put(Items.COBBLED_DEEPSLATE, 1);
        P.put(Items.SAND, 1);
        P.put(Items.WHEAT, 1);
        P.put(Items.COAL, 3);
        P.put(Items.RAW_COPPER, 3);
        P.put(Items.LAPIS_LAZULI, 3);
        P.put(Items.REDSTONE, 2);
        P.put(Items.RAW_IRON, 5);
        P.put(Items.IRON_INGOT, 8);
        P.put(Items.RAW_GOLD, 8);
        P.put(Items.GOLD_INGOT, 12);
        P.put(Items.EMERALD, 25);
        P.put(Items.DIAMOND, 40);
    }

    private Prices() {}

    public static int unitPrice(ItemStack s) {
        if (s.isEmpty()) return 0;
        if (s.is(ItemTags.LOGS)) return 2;
        return P.getOrDefault(s.getItem(), 0);
    }

    /** Продаёт предмет в основной руке. Возвращает полученную сумму (0 = не покупают). */
    public static long sellHand(ServerPlayer p) {
        ItemStack s = p.getMainHandItem();
        int unit = unitPrice(s);
        if (unit <= 0) return 0;
        long total = (long) unit * s.getCount();
        s.setCount(0);
        EconomyManager.add(p.getUUID(), total);
        return total;
    }

    /** Продаёт всё продаваемое из инвентаря. */
    public static long sellAll(ServerPlayer p) {
        Inventory inv = p.getInventory();
        long total = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getItem(i);
            int unit = unitPrice(s);
            if (unit > 0) {
                total += (long) unit * s.getCount();
                inv.setItem(i, ItemStack.EMPTY);
            }
        }
        if (total > 0) EconomyManager.add(p.getUUID(), total);
        return total;
    }
}
