package com.example.moneymod;

public enum Unlock {
    JUMP("jump", "Прыгать", 10),
    ATTACK("attack", "Бить", 20),
    PLACE("place", "Ставить блоки", 30),
    BREAK("break", "Ломать блоки", 50);

    public final String id;
    public final String title;
    public final long price;

    Unlock(String id, String title, long price) {
        this.id = id;
        this.title = title;
        this.price = price;
    }

    public static Unlock byId(String id) {
        for (Unlock u : values()) {
            if (u.id.equalsIgnoreCase(id)) return u;
        }
        return null;
    }
}
